const version = {
  version: "0.0.0",
  branch: "master",
  git: "aaaaaaa"
};
