
const ipaConfig = {
  appName: "",
  applicationId: "db26d8df-01a4-4d42-8d6c-3b8c5440a71e",
  configUserType: 'dev-train',
  scriptPlugins: [
  ],
  redux: {
    slices: [
    ]
  },
  components: {
    dashboard: [
    ],
    entityData: [
    ],
    entityAction: [
    ]
  }
}

export default ipaConfig