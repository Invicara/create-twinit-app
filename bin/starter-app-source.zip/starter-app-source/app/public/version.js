const version = {
  package: "0.0.0",
  branch: "master",
  git: "aaaaaaa"
};

